//MANEJO DEL INVENTARIO
import Product from '../../models/product/product.model.js';

export const addProduct = async (req, res) => {
    try {
        let data = req.body;
    } catch (e) {
        console.error(e);
        return res.status(500).send({ success: false, message: 'General error', e });
    }
}